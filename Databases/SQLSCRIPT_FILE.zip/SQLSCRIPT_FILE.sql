﻿DROP DATABASE IF EXISTS IT_Database;
CREATE DATABASE IT_Database;
USE IT_Database;
CREATE TABLE Customer (
	Customer_Email varchar(50)PRIMARY KEY NOT NULL,
	Customer_FirstName varchar(150) NOT NULL,
	Customer_LastName varchar(150) NOT NULL,
	Customer_HouseNumber varchar(60) NOT NULL,
    	Customer_StreetName varchar(90) NOT NULL,
    	Customer_City varchar(60) NOT NULL,
	Customer_Postcode varchar(12) NOT NULL,
    	Customer_Homephone int NOT NULL
);

CREATE TABLE Staff (	
	Staff_Email varchar(50) PRIMARY KEY NOT NULL,
    	Staff_FirstName varchar(40) NOT NULL,
	Staff_LastName varchar(40) NOT NULL
);

CREATE TABLE Services (
	Service_Name varchar(80) PRIMARY KEY NOT NULL,
	Service_Description varchar(255) NOT NULL,
	Service_Price decimal(5,2) NOT NULL
);

CREATE TABLE Orders (
	Order_Time DATETIME PRIMARY KEY NOT NULL,
	Customer_Email varchar(90) NOT NULL,
	Service_Name varchar(60) NOT NULL,
	Staff_Email varchar(40) NOT NULL,
	Total_Cost decimal(7,2) NOT NULL,
	Discount varchar(50),
	Quantity int(50) NOT NULL,
    FOREIGN KEY (Staff_Email) REFERENCES Staff(Staff_Email),
    FOREIGN KEY (Service_Name) REFERENCES Services(Service_Name),
    FOREIGN KEY (Customer_Email) REFERENCES Customer(Customer_Email)
);

ALTER TABLE Customer
DROP COLUMN Customer_Homephone,
ADD Customer_Number varchar(45);

/*Customer Records*/

INSERT INTO Customer (Customer_Email, Customer_FirstName, Customer_LastName, Customer_HouseNumber, Customer_StreetName, Customer_City, Customer_Postcode, Customer_Number)
VALUES ('myaic@gmail.com', 'Mia', 'Smith', '67', 'Coburn Road', 'London', 'WC94 0MC', '07567256123');

INSERT INTO Customer (Customer_Email, Customer_FirstName, Customer_LastName, Customer_HouseNumber, Customer_StreetName, Customer_City, Customer_Postcode, Customer_Number)
VALUES ('stee.corrig@yahoo.com', 'Steve', 'Corrigan', '9', 'Grove Walk', 'Birmingham', 'B58 5HN', '07653322984');

INSERT INTO Customer (Customer_Email, Customer_FirstName, Customer_LastName, Customer_HouseNumber, Customer_StreetName, Customer_City, Customer_Postcode, Customer_Number)
VALUES ('aquttolin-8530@yopmail.com', 'Andrea', 'Hester', '140', 'Queensway', 'Rochester', 'ME58 7XU', '07349785514');

INSERT INTO Customer (Customer_Email, Customer_FirstName, Customer_LastName, Customer_HouseNumber, Customer_StreetName, Customer_City, Customer_Postcode, Customer_Number)
VALUES ('kelenoqagy-5121@outlook.com', 'Hellen', 'Borrke', '55', 'High Street', 'Harrow', 'HA63 3EJ', '07345790289');
        
INSERT INTO Customer (Customer_Email, Customer_FirstName, Customer_LastName, Customer_HouseNumber, Customer_StreetName, Customer_City, Customer_Postcode, Customer_Number)
VALUES ('mike.fimme-3910@outlook.com', 'Micheal', 'Winnifred', '14', 'Victoria Street', 'Sunderland', 'SR53 5VG', '07523526236');

INSERT INTO Customer (Customer_Email, Customer_FirstName, Customer_LastName, Customer_HouseNumber, Customer_StreetName, Customer_City, Customer_Postcode, Customer_Number)
VALUES ('owatehox-6397@gmail.com', 'Omar', 'Nineve', '90', 'New Road', 'Edinburgh', 'EH72 7PD', '07265959589');

INSERT INTO Customer (Customer_Email, Customer_FirstName, Customer_LastName, Customer_HouseNumber, Customer_StreetName, Customer_City, Customer_Postcode, Customer_Number)
VALUES ('nazossuzibe-4163@yahoomail.com', 'Natalie', 'Zenia', '290', 'Grange Road', 'Lerwick', 'ZE5 5UP', '07386892165');

INSERT INTO Customer (Customer_Email, Customer_FirstName, Customer_LastName, Customer_HouseNumber, Customer_StreetName, Customer_City, Customer_Postcode, Customer_Number)
VALUES ('ellusuddob-6914@gmail.com', 'Ellen', 'Suddon', '45', 'Park Lane', 'Bolton', 'BL11 8VQ', '07824672686');

INSERT INTO Customer (Customer_Email, Customer_FirstName, Customer_LastName, Customer_HouseNumber, Customer_StreetName, Customer_City, Customer_Postcode, Customer_Number)
VALUES ('mat.perry-6914@yahoo.com', 'Mathew', 'Perry', '20', 'King Street', 'Dundee', 'DD27 6UY', '07687252457');

INSERT INTO Customer (Customer_Email, Customer_FirstName, Customer_LastName, Customer_HouseNumber, Customer_StreetName, Customer_City, Customer_Postcode, Customer_Number)
VALUES ('pete.chappers432@outlook.com', 'Peter', 'Chapman', '2', 'Richmond Road', 'Dartford', 'DA13 4HQ', '07658764412');

INSERT INTO Customer (Customer_Email, Customer_FirstName, Customer_LastName, Customer_HouseNumber, Customer_StreetName, Customer_City, Customer_Postcode, Customer_Number)
VALUES ('day.simon22@outlook.com', 'Simon', 'Day', '5', 'Lavender Avenue', 'Lincoln', 'LN12 7ET', '07542175612');

INSERT INTO Customer (Customer_Email, Customer_FirstName, Customer_LastName, Customer_HouseNumber, Customer_StreetName, Customer_City, Customer_Postcode, Customer_Number)
VALUES ('wright.alice99@gmail.com', 'Alice', 'Wright', '54', 'South Street', 'Sheffield', 'SH4 9OW', '07456498414');

INSERT INTO Customer (Customer_Email, Customer_FirstName, Customer_LastName, Customer_HouseNumber, Customer_StreetName, Customer_City, Customer_Postcode, Customer_Number)
VALUES ('cruzooz88@outlook.com', 'Zoe', 'Cruz', '93', 'Swan Walk', 'Portmouth', 'PO2 7MQ', '07465436548');

INSERT INTO Customer (Customer_Email, Customer_FirstName, Customer_LastName, Customer_HouseNumber, Customer_StreetName, Customer_City, Customer_Postcode, Customer_Number)
VALUES ('jones.gina11@yahoo.com', 'Gina', 'Jones', '9', 'Pathstone Road', 'Grimsby', 'DN6 10KJ', '07567213498');

INSERT INTO Customer (Customer_Email, Customer_FirstName, Customer_LastName, Customer_HouseNumber, Customer_StreetName, Customer_City, Customer_Postcode, Customer_Number)
VALUES ('richardlang@gmail.com', 'Richard', 'Langford', '61', 'Wellesley Road', 'Manchester', 'MA3 2MN', '07466823145');

INSERT INTO Customer (Customer_Email, Customer_FirstName, Customer_LastName, Customer_HouseNumber, Customer_StreetName, Customer_City, Customer_Postcode, Customer_Number)
VALUES ('wesstdaniel2@gmail.com', 'Daniel', 'West', '01', 'Streamer Steet', 'Belfast', 'BE1 6EN', '07469355745');

INSERT INTO Customer (Customer_Email, Customer_FirstName, Customer_LastName, Customer_HouseNumber, Customer_StreetName, Customer_City, Customer_Postcode, Customer_Number)
VALUES ('lillpete223@gmail.com', 'Pete', 'Lilliker', '51', 'Dogget Road', 'Nottingham', 'NG3 9OW', '07175884652');

INSERT INTO Customer (Customer_Email, Customer_FirstName, Customer_LastName, Customer_HouseNumber, Customer_StreetName, Customer_City, Customer_Postcode, Customer_Number)
VALUES ('ghan.r@hotmail.com', 'Riley', 'Ghan', '90', 'Fartherly Walk', 'Leeds', 'LE2 2LK', '07964545723');

INSERT INTO Customer (Customer_Email, Customer_FirstName, Customer_LastName, Customer_HouseNumber, Customer_StreetName, Customer_City, Customer_Postcode, Customer_Number)
VALUES ('smith.s554@outlook.com', 'Samantha', 'Smith', '141', 'Acacia Avenue', 'London', 'LN4 GTN', '07567115686');

INSERT INTO Customer (Customer_Email, Customer_FirstName, Customer_LastName, Customer_HouseNumber, Customer_StreetName, Customer_City, Customer_Postcode, Customer_Number)
VALUES ('themazzeti@hotmail.com', 'Liam', 'Mazzeti', '75', 'Rawter Road', 'Liverpool', 'L1 8JW', '07753753654');

INSERT INTO Customer (Customer_Email, Customer_FirstName, Customer_LastName, Customer_HouseNumber, Customer_StreetName, Customer_City, Customer_Postcode, Customer_Number)
VALUES ('holloway.amy52@yahoo.com', 'Amy', 'Holloway', '09', 'Arch Steet', 'Glasgow', 'G1 2AC', '07160740896');

/*2.1*/ DELETE FROM Customer WHERE Customer_Email='wesstdaniel2@gmail.com';

/*Staff Records*/

INSERT INTO Staff (Staff_Email, Staff_FirstName, Staff_LastName)
VALUES ('williams.ian555@yahoo.com', 'Ian', 'Williams');

INSERT INTO Staff (Staff_Email, Staff_FirstName, Staff_LastName)
VALUES ('clarkeff@gmail.com', 'Harry', 'Clarke');

INSERT INTO Staff (Staff_Email, Staff_FirstName, Staff_LastName)
VALUES ('terry12@gmail.com', 'Terry', 'White');

INSERT INTO Staff (Staff_Email, Staff_FirstName, Staff_LastName)
VALUES ('rogerfhansen51@yahoo.com', 'Roger', 'Hansen');

INSERT INTO Staff (Staff_Email, Staff_FirstName, Staff_LastName)
VALUES ('abigailzz@gmail.com', 'Abigail', 'Bray');

INSERT INTO Staff (Staff_Email, Staff_FirstName, Staff_LastName)
VALUES ('stanjason222@gmail.com', 'Jason', 'Stanhope');

INSERT INTO Staff (Staff_Email, Staff_FirstName, Staff_LastName)
VALUES ('OHorton778@outlook.com', 'Oliver', 'Horton');

INSERT INTO Staff (Staff_Email, Staff_FirstName, Staff_LastName)
VALUES ('walker.nathan@yahoo.com', 'Nathan', 'Walker');

INSERT INTO Staff (Staff_Email, Staff_FirstName, Staff_LastName)
VALUES ('teddybears@gmail.com', 'Jake', 'Steel');

INSERT INTO Staff (Staff_Email, Staff_FirstName, Staff_LastName)
VALUES ('theolivia@outlook.com', 'Olivia', 'Taylor');

INSERT INTO Staff (Staff_Email, Staff_FirstName, Staff_LastName)
VALUES ('s.polley@yahoo.com', 'Sally', 'Polley');

INSERT INTO Staff (Staff_Email, Staff_FirstName, Staff_LastName)
VALUES ('clifden12@outlook.com', 'Hayden', 'Clifton');

INSERT INTO Staff (Staff_Email, Staff_FirstName, Staff_LastName)
VALUES ('thehutch.s@gmail.com', 'Samuel', 'Hutchinson');

INSERT INTO Staff (Staff_Email, Staff_FirstName, Staff_LastName)
VALUES ('Chambers9@outlook.com', 'Everlyn', 'Chambers');

INSERT INTO Staff (Staff_Email, Staff_FirstName, Staff_LastName)
VALUES ('waraddis55@outlook.com', 'Warren', 'Addison');

INSERT INTO Staff (Staff_Email, Staff_FirstName, Staff_LastName)
VALUES ('preston.alex77@outlook.com', 'Alex', 'Preston');


/*2.1*/ DELETE FROM Staff WHERE Staff_Email='teddybears@gmail.com';



/*Services Records*/

INSERT INTO Services (Service_Name, Service_Description, Service_Price)
VALUES ('Upgrading', 'Upgrade your current hardware and/or software. Prices vary', '45.00');

INSERT INTO Services (Service_Name, Service_Description, Service_Price)
VALUES ('Hardware Repairs', 'Upgrade or fix your current hardware and/or software. Prices vary', '6.00');

INSERT INTO Services (Service_Name, Service_Description, Service_Price)
VALUES ('Software', 'Software setup', '20.00');

INSERT INTO Services (Service_Name, Service_Description, Service_Price)
VALUES ('Networking', 'Setup and installation', '225.00');

INSERT INTO Services (Service_Name, Service_Description, Service_Price)
VALUES ('Training', 'Train IT skills to individuals or a group', '70.00');

INSERT INTO Services (Service_Name, Service_Description, Service_Price)
VALUES ('Physical Backup', 'The company will backup customer data on their behalf. £42 per TB.', '45.00');

INSERT INTO Services (Service_Name, Service_Description, Service_Price)
VALUES ('Cloud Backup', 'The company will store one Terabyte per month for £25.', '25.00');

INSERT INTO Services (Service_Name, Service_Description, Service_Price)
VALUES ('Antivirus & Firewall Setup', 'Setup and installation on behalf of the customer. Purchase of antivirus and firewalls are sold seperately however.', '25.00');

INSERT INTO Services (Service_Name, Service_Description, Service_Price)
VALUES ('Maintenance Check', 'An employee will check the customers hardware/software and perform a maintence check.', '50.00');

INSERT INTO Services (Service_Name, Service_Description, Service_Price)
VALUES ('Customer Support & Advice Subscription', '£10 a month for customers to contact the company and ask for support.', '10.00');

INSERT INTO Services (Service_Name, Service_Description, Service_Price)
VALUES ('Trade-Ins', 'Trade-ins for store credit or cash. No charge applied here.', '0.00');

INSERT INTO Services (Service_Name, Service_Description, Service_Price)
VALUES ('PC Building', 'The company will build a customers PC on their behalf.', '75.00');

INSERT INTO Services (Service_Name, Service_Description, Service_Price)
VALUES ('Computer Optimisation', 'Various optimisation options including defragging, removing redundant files and updating current software.', '30.00');

INSERT INTO Services (Service_Name, Service_Description, Service_Price)
VALUES ('Cable Management', 'An employee can set up cables for the customer.', '10.00');

INSERT INTO Services (Service_Name, Service_Description, Service_Price)
VALUES ('Reboot PC', 'An employee will completely restart a customers PC from scratch and set it back up.', '30.00');

/*2.1*/UPDATE Services
SET Service_Price = '200'
WHERE Service_Name = 'Networking';

UPDATE Services
SET Service_Price = '42'
WHERE Service_Name = 'Physical Backup'; /*2.1*/

/*Orders Records*/

INSERT INTO Orders (Order_Time, Customer_Email, Service_Name, Staff_Email, Total_Cost, Discount, Quantity)
VALUES ('2019-09-05 10:14:34', 'myaic@gmail.com', 'Upgrading', 'walker.nathan@yahoo.com', '90.00', 'No', '2');

INSERT INTO Orders (Order_Time, Customer_Email, Service_Name, Staff_Email, Total_Cost, Discount, Quantity)
VALUES ('2019-09-08 15:35:15', 'stee.corrig@yahoo.com', 'Training', 'abigailzz@gmail.com', '70.00', 'No', '5');

INSERT INTO Orders (Order_Time, Customer_Email, Service_Name, Staff_Email, Total_Cost, Discount, Quantity)
VALUES ('2019-09-30 09:20:51', 'aquttolin-8530@yopmail.com', 'Antivirus & Firewall Setup', 'williams.ian555@yahoo.com', '25.00', 'No', '1');

INSERT INTO Orders (Order_Time, Customer_Email, Service_Name, Staff_Email, Total_Cost, Discount, Quantity)
VALUES ('2019-08-22 09:09:29', 'kelenoqagy-5121@outlook.com', 'PC Building', 'clarkeff@gmail.com', '75.00', 'No', '1');

INSERT INTO Orders (Order_Time, Customer_Email, Service_Name, Staff_Email, Total_Cost, Discount, Quantity)
VALUES ('2019-09-14 12:09:21', 'mike.fimme-3910@outlook.com', 'Software', 'stanjason222@gmail.com', '60.00', 'No', '3');

INSERT INTO Orders (Order_Time, Customer_Email, Service_Name, Staff_Email, Total_Cost, Discount, Quantity)
VALUES ('2019-09-07 16:30:01', 'owatehox-6397@gmail.com', 'Cable Management', 'theolivia@outlook.com', '20.00', 'No', '2');

INSERT INTO Orders (Order_Time, Customer_Email, Service_Name, Staff_Email, Total_Cost, Discount, Quantity)
VALUES ('2019-08-27 13:55:24', 'nazossuzibe-4163@yahoomail.com', 'Customer Support & Advice Subscription', 'stanjason222@gmail.com', '10.00', 'No', '1');

INSERT INTO Orders (Order_Time, Customer_Email, Service_Name, Staff_Email, Total_Cost, Discount, Quantity)
VALUES ('2019-08-30 14:23:44', 'ellusuddob-6914@gmail.com', 'Cloud Backup', 'terry12@gmail.com', '25.00', 'No', '1');

INSERT INTO Orders (Order_Time, Customer_Email, Service_Name, Staff_Email, Total_Cost, Discount, Quantity)
VALUES ('2019-08-16 11:08:11', 'mat.perry-6914@yahoo.com', 'Hardware Repairs', 'theolivia@outlook.com', '42.00', 'No', '7');

INSERT INTO Orders (Order_Time, Customer_Email, Service_Name, Staff_Email, Total_Cost, Discount, Quantity)
VALUES ('2019-09-29 15:12:49', 'pete.chappers432@outlook.com', 'Computer Optimisation', 'abigailzz@gmail.com', '30.00', 'No', '1');

INSERT INTO Orders (Order_Time, Customer_Email, Service_Name, Staff_Email, Total_Cost, Discount, Quantity)
VALUES ('2019-10-02 11:45:23', 'day.simon22@outlook.com', 'Reboot PC', 'clifden12@outlook.com', '30.00', 'No', '1');

INSERT INTO Orders (Order_Time, Customer_Email, Service_Name, Staff_Email, Total_Cost, Discount, Quantity)
VALUES ('2019-10-04 09:58:38', 'wright.alice99@gmail.com', 'Cloud Backup', 'clifden12@outlook.com', '25.00', 'No', '1');

INSERT INTO Orders (Order_Time, Customer_Email, Service_Name, Staff_Email, Total_Cost, Discount, Quantity)
VALUES ('2019-08-24 11:42:27', 'cruzooz88@outlook.com', 'Training', 'thehutch.s@gmail.com', '70.00', 'No', '1');

INSERT INTO Orders (Order_Time, Customer_Email, Service_Name, Staff_Email, Total_Cost, Discount, Quantity)
VALUES ('2019-08-30 11:06:10', 'jones.gina11@yahoo.com', 'Antivirus & Firewall Setup', 'waraddis55@outlook.com', '50.00', 'No', '2');

INSERT INTO Orders (Order_Time, Customer_Email, Service_Name, Staff_Email, Total_Cost, Discount, Quantity)
VALUES ('2019-09-14 15:17:18', 'richardlang@gmail.com', 'Cable Management', 'Chambers9@outlook.com', '40.00', 'No', '4');

/*Query 1 | 2.2*/

SELECT Orders.Order_Time, Customer.*
FROM Orders
RIGHT JOIN Customer ON Orders.Customer_Email = Customer.Customer_Email;

/*Query 2 | 2.3*/

SELECT Staff.*, Orders.*
FROM Staff
LEFT JOIN Orders ON Staff.Staff_Email = Orders.Staff_Email;

/*Query 3 | 2.4*/

SELECT Orders.*, Customer.Customer_FirstName, Customer.Customer_LastName
FROM Orders
INNER JOIN Customer ON Orders.Customer_Email = Customer.Customer_Email; 


/*2.6*/

CREATE TABLE copy_of_customer LIKE Customer;
INSERT INTO copy_of_customer SELECT * FROM Customer;

CREATE TABLE copy_of_staff LIKE Staff;
INSERT INTO copy_of_staff SELECT * FROM Staff;

CREATE TABLE copy_of_services LIKE Services;
INSERT INTO copy_of_services SELECT * FROM Services;

CREATE TABLE copy_of_orders LIKE Orders;
INSERT INTO copy_of_orders SELECT * FROM Orders;


/*2.7*/

CREATE PROCEDURE `selectOrders`() SELECT * FROM Orders;
CALL `selectOrders`();
SET @p0='2019-09-05 10:14:34'; CALL `selectOrders`(@p0, @p1); SELECT @p1 AS `Quantity2`;


